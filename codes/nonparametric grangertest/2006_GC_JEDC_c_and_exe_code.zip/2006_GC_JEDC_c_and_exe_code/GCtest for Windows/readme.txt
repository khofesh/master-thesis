This is a Windows friendly version of the test for non-parametric Granger Causality.

This version is developed by Valentyn Panchenko. 
For questions/comments email v.panchenko@unsw.edu.au

PROGRAM TO RUN:
GCtest-win.exe

INSTRUCTIONS:
Input file1 and input file2 should be single column files of
numerical data in txt format. Columns need to be the same
length, otherwise you will receive an error message.

You may either use a slider or enter the embedding dimention
and bandwidth manually.

Embedding dimension = 1 + maximum lag (Lx=Ly).
Defauld bandwidth choice is 0.5, read the paper for more details.

EXAMLE:
You may try using in1.txt and in2.txt as an example.

Expected output:

Series length=4136, embedding dimension=2, bandwidth=0.500000

Null hypothesis: in1.txt does not cause in2.txt
T statistics=1.448, p-value=0.07380

Null hypothesis: in2.txt does not cause in1.txt
T statistics=1.930, p-value=0.02678


NOTE: you need to keep all the .dll files in the program
directory for program to run.


Please cite:

Diks, C. & Panchenko V. (2006) A new statistic and practical guidelines
for nonparametric Granger causality testing, 2006, Journal of
Economic Dynamics and Control, 30, 1647-1669

	
Diks, C. & Panchenko, V. (2005) A note on the Hiemstra-Jones test for Granger
non-causality. Studies in Nonlinear Dynamics & Econometrics, 9(2).